import React from 'react'

function App() {
  return (
    <div>
      <h1>Bienvenue sur TamusnAI !</h1>
      <p>Votre assistant intelligent kabyle.</p>
    </div>
  )
}

export default App
